package com.kh.filoom.member.model.service;

import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService{

}
