package com.kh.filoom.member.model.service;

public interface MemberService {

}
