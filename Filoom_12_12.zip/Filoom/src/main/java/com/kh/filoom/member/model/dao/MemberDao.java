package com.kh.filoom.member.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class MemberDao {

}
